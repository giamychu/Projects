import React from "react";
import axios from "axios";
import { useEffect, useState } from "react";
import './AxiosCss.css';


//function add character
function Add({}) {
    const [id, setId] = useState("");
    const [gameCharacterName, setGameCharacterName] = useState("");
    const [game, setGame] = useState("");
    const [image, setImage] = useState("");
    const [newCharacter, setNewCharacter] = useState("");
    const [file, setFile] = useState("");
    const [selectedImage, setSelectedImage] = useState("");

    //axios post
    const onAddCharacter= async (newCharacter, selectedImage)=>{
        await axios.post('https://localhost:7240/api/GameCharacter', 
        JSON.stringify(newCharacter), 
        {
            headers: {
            'Content-Type': 'application/json'
            }
        })
        .then((response)=>{setNewCharacter(undefined)})
        .catch(error => {console.log(error);});

        const formData = new FormData();
        formData.append("file", selectedImage);
        try {
            const response = await axios({
                method: "post",
                url: `https://localhost:7240/api/GameCharacter/SaveImage`,
                data: formData,
                headers: { "Content-Type": "multipart/form-data" },
            });
        } catch(error) {
            console.log(error)
        }
    }

    useEffect(() => {
        setNewCharacter({ id, gameCharacterName, game, image, file });
    }, [id, gameCharacterName, game, image, file]);

    async function handleSubmit (event) { 
        event.preventDefault()
        await onAddCharacter(newCharacter, selectedImage)
    }
    const handleFileSelect = (event) => {
        setSelectedImage(event.target.files[0]);
        setFile(event.target.files[0].name);
    }

    return (
        <form onSubmit={handleSubmit}>
        <div className="div">
            <h3>ADD A GAME CHARACTER</h3>
            <div>
                <div>
                    <label>Id (automatically assigned)</label>
                </div>

                <div>
                    <label>Name:</label>
                    <input type="text" id="add-game-gameCharacterName" placeholder="Enter Name" onChange={(e) => setGameCharacterName(e.target.value)}></input>
                </div>

                <div>
                    <label>Name of Game:</label>
                    <input type="text" id="add-game-game" placeholder="Enter game" onChange={(e) => setGame(e.target.value)}></input>
                </div>
            </div>
           
            <input type="file" id="add-book-image" onChange={handleFileSelect}/>
          
            <div>
            <p>Remember to refresh the page to see the changes</p>
            <input type="submit" id="add-book-btn" value="Add" /> 
            </div>
           
        </div>
        </form>
    )
}
export default Add;