import React from "react";
import axios from "axios";
import { useEffect, useState } from "react";
import './AxiosCss.css';



function Search() {
    const [GameCharacter, setGameCharacter] = useState([]);
    const [searchId, setSearchId] = useState("");
    const [searchName, setSearchName] = useState("");
    const imageUrl = "https://localhost:7240/images";

    //function search character by ID
    //axios get
    function searchCharacterById() {
        axios.get(`https://localhost:7240/api/GameCharacter/${searchId}`,
            {
                headers: {
                    'Access-Control-Allow-Origin': '*',
                    'Access-Control-Allow-Methods': 'GET,PUT,POST,DELETE,PATCH,OPTIONS',
                }
            })
            .then((response) => {
                var gameCharacterArray = [];
                console.log(response.data)
                gameCharacterArray.push(response.data)
                setGameCharacter(gameCharacterArray)
            })
            .catch(error => {
                console.log(error);
            });
    }

    //function search character by Name
    //axios get
    function searchCharacterByName() {
        axios.get(`https://localhost:7240/api/GameCharacter/name/${searchName}`,
            {
                headers: {
                    'Access-Control-Allow-Origin': '*',
                    'Access-Control-Allow-Methods': 'GET,PUT,POST,DELETE,PATCH,OPTIONS',
                }
            })
            .then((response) => {
                setGameCharacter(response.data)
            })
            .catch(error => {
                console.log(error);
            });
    }

    return (
        <div>
            <div>
                <div className="div">
                    <h3>SEARCH BY ID</h3>
                    <input type="text" id="search-character-Id" placeholder="Enter Id" onChange={(e) => setSearchId(e.target.value)}></input>
                    <button id="search-character-id-btn" onClick={searchCharacterById}>Search</button>
                </div>

                <div className="div">
                    <h3>SEARCH BY NAME</h3>
                    <input type="text" id="search-character-Name" placeholder="Enter name" onChange={(e) => setSearchName(e.target.value)}></input>
                    <button id="search-character-name-btn" onClick={searchCharacterByName}>Search</button>
                </div>
            </div>
            <div className="search-wrapper">
                {GameCharacter.map(GameCharacters => {
                    return (
                        <div className="search-output">
                            <p><strong>ID:</strong> {GameCharacters.id}</p>
                            <p><strong>Name:</strong> {GameCharacters.gameCharacterName}</p>
                            <p><strong>Game:</strong>{GameCharacters.game}</p>
                            <img className="images" src={`${imageUrl}/${encodeURIComponent(GameCharacters.image)}`} alt={GameCharacters.id} ></img>
                        </div>
                    );
                })}
            </div>
        </div>);
}

export default Search;