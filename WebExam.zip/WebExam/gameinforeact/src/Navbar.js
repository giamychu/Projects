import { BrowserRouter as Router, Routes, Route, Link, useNavigate } from "react-router-dom";
import Home from './Home';
import Search from './Search';
import Delete from './Delete';
import Add from './Add';
import Quiz from './Quiz';
import Update from './Update';
import './AxiosCss.css';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faHome, faGamepad, faMagnifyingGlass, faCirclePlus, faCircleMinus, faPenToSquare } from "@fortawesome/free-solid-svg-icons";


//Navbar med fontawesome ikoner
function Navbar() {
    return (
        <Router>
            <nav className="nav">
                
                <Link className="home links" to="/home">Home   <FontAwesomeIcon icon={faHome} /></Link>
                <div className="icon-link-div">
                    <FontAwesomeIcon className="icon" icon={faMagnifyingGlass} />
                    <Link className="search links" to="/search">Search </Link>
                </div>
                <div className="icon-link-div">
                <FontAwesomeIcon className="icon" icon={faCircleMinus} />
                    <Link className="delete links" to="/delete">Delete</Link>
                </div>

                <div className="icon-link-div">
                    <FontAwesomeIcon className="icon" icon={faCirclePlus} />
                    <Link className="add links" to="/add">Add </Link>
                </div>

                <div className="icon-link-div">
                <FontAwesomeIcon className="icon" icon={faPenToSquare} />
                    <Link className="update links" to="/update">Update</Link>
                </div>
                <div className="icon-link-div">
                    <FontAwesomeIcon className="icon" icon={faGamepad} />
                    <Link className="quiz links" to="/quiz">Quiz </Link>
                </div>
            </nav>

            <Routes>
                <Route path="/home" element={<Home />} />
                <Route path="/search" element={<Search />} />
                <Route path="/delete" element={<Delete />} />
                <Route path="/add" element={<Add />} />
                <Route path="/update" element={<Update />} />
                <Route path="/quiz" element={<Quiz />} />
            </Routes>

        </Router>
    )
}

export default Navbar;

