import React from "react";
import { useEffect, useState } from "react";
import './AxiosCss.css';

function Quiz() {

    const [finalScore, setFinalScore] = useState(false);
    const [score, setScore] = useState(0);
    const [ongoingQuestion, setOngoingQuestion] = useState(0);

    //array with questions 
    const quizQuestions = [
        {
            text: "When was the Playstation 5 released?",
            answerAlternatives: [
                { id: 0, text: "November 2021", isCorrect: false },
                { id: 1, text: "Januar2020", isCorrect: false },
                { id: 2, text: "November 2020", isCorrect: true },
               
            ],
        },
        {
            text: "What is the best selling video games of all time?",
            answerAlternatives: [
                { id: 0, text: "Minecraft", isCorrect: true },
                { id: 1, text: "Valorant", isCorrect: false },
                { id: 2, text: "Fifa", isCorrect: false },
              
            ],
        },
        {
            text: "What is the fictional language in The Sims?  ",
            answerAlternatives: [
                { id: 0, text: "Simian", isCorrect: false },
                { id: 1, text: "Simlish", isCorrect: true },
                { id: 2, text: "Simento", isCorrect: false },
            ],
        },
        {
            text: "How many Playstation 4 consoles have been sold?",
            answerAlternatives: [
                { id: 0, text: "117.2 million", isCorrect: true },
                { id: 1, text: "1.2 billion", isCorrect: false },
                { id: 2, text: "170.3 million", isCorrect: false },
            ],
        },
        {
            text: "what year was mario bros released?",
            answerAlternatives: [
                { id: 0, text: "1975", isCorrect: false },
                { id: 1, text: "1983", isCorrect: true },
                { id: 2, text: "1989", isCorrect: false },
            ],
        },
    ];

    //score feedback
    const scoreStatus = () => {
        if(score <= 2){
            return(
                <h2>Nice try!</h2>
            )
        }
        if(score >= 3 ){
            return(
                <h2>Great job!</h2>
                )
        }
    }

    //one of the answer alternatives clicked
    const alternativeClicked = (isCorrect) => {
        if (isCorrect) {
            setScore(score + 1)
        }

        if (ongoingQuestion + 1 < quizQuestions.length) {
            setOngoingQuestion(ongoingQuestion + 1)
        } else{
            setFinalScore(true);
        }

    }

    // restarts the game
    const playAgain = () =>{
        setScore(0);
        setOngoingQuestion(0);
        setFinalScore(false);
    }
    return (
        <div className="quiz">
            <h1 className="quiz-header">Game Quiz</h1>
            <h4>Test your knowledge about Javascript!</h4>
           
            {/* finalscore */}
            {finalScore ? (
                <div className="final-score">
                    <h1>Final Score</h1>
                    <h2> {score} / {quizQuestions.length} correct answers</h2>
                    <h2 className="score-status">{scoreStatus()}</h2>
                    <button className="btn" onClick={() => playAgain()}>Play again</button>
                </div>
            ) : (

                // Quiz questions
                <div className="questions">
                    <h2>Question {ongoingQuestion + 1} / {quizQuestions.length}</h2>
                    <h3>{quizQuestions[ongoingQuestion].text}</h3>

                    <ul className="list-ul">
                        {quizQuestions[ongoingQuestion].answerAlternatives.map((alternative) => {
                            return (
                                <li onClick={() => alternativeClicked(alternative.isCorrect)} className="list" key={alternative.idea}>{alternative.text}</li>
                            );
                        })}
                    </ul>
                    <h2>Current score: {score}</h2>
                </div>

            )}

        </div>
    )
}

export default Quiz;