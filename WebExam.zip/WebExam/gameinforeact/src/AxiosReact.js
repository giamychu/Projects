import axios from "axios";
import { useEffect, useState } from "react";
import Navbar from './Navbar';
import './AxiosCss.css';

function AxiosReact() {
    const [GameCharacter, setGameCharacter] = useState([]);
    const [newCharacter, setNewCharacter] = useState("");
    const [deletedCharacter, setDeletedCharacter] = useState("");
    const [updatedCharacter, setUpdatedCharacter] = useState("");


    //link to images
    const imageUrl = "https://localhost:7240/images";

    //get
    useEffect(() => {
        axios
            .get("https://localhost:7240/api/GameCharacter", {
                headers: {
                    'Access-Control-Allow-Origin': '*',
                    'Access-Control-Allow-Methods': 'GET,PUT,POST,DELETE,PATCH,OPTIONS',
                }
            })
            .then((response) => setGameCharacter(response.data))
            .catch(error => console.log(error))
    }, [newCharacter, deletedCharacter, updatedCharacter]);


    return (

        <div>
            <Navbar />
            <div className="wrapper">
                {GameCharacter.map(GameCharacters => {
                    return (
                        <div className="output">
                            <p><strong>ID:</strong> {GameCharacters.id}</p>
                            <p><strong>Name:</strong> {GameCharacters.gameCharacterName}</p>
                            <p><strong>Game:</strong>{GameCharacters.game}</p>
                            <img className="images" src={`${imageUrl}/${encodeURIComponent(GameCharacters.image)}`} alt={GameCharacters.id} ></img>
                        </div>
                    );
                })}

            </div>

        </div>

    )

}


export default AxiosReact;