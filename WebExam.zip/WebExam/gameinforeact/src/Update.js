import React from "react";
import axios from "axios";
import { useEffect, useState } from "react";
import './AxiosCss.css';


//function update character
function Update({ onUpdateCharacter}) {
    const [updatedId, setUpdatedId] = useState("");
    const [updatedName, setUpdatedName] = useState("");
    const [updatedGame, setUpdatedGame] = useState("");
    const [updatedImage, setUpdatedImage] = useState("");
    const [updatedCharacter, setUpdatedCharacter] = useState({});

    //axios put
    function onUpdateCharacter(updatedId) {
      axios.put(`https://localhost:7240/api/GameCharacter/${updatedId}`,
            JSON.stringify(updatedCharacter),
            {
                headers: { 'Content-Type': 'application/json' }
            })
            .then((response) => {
              setUpdatedCharacter({ ...updatedCharacter })
             console.log(response)
            })
            .catch(error => { console.log(error.message); });
    } 


    useEffect(() => {
        setUpdatedCharacter({
            Id: updatedId ? updatedId : updatedCharacter.Id,
            GameCharacterName: updatedName ? updatedName : updatedCharacter.GameCharacterName,
            Game: updatedGame ? updatedGame : updatedCharacter.Name,
            Image: updatedImage ? updatedImage : updatedCharacter.Image,
        })
        console.log(updatedCharacter)
    }, [updatedId, updatedName, updatedGame, updatedImage]);
    
    function UpdateCharacter() {
        onUpdateCharacter(updatedId)
    }

    return (
        <div className="div">
            <h3>UPDATE A GAME CHARACTER</h3>
            <div>
                <div >
                    <label>Id:</label>
                     <input type="text" id="update-game-Id" placeholder="Update Id" value={updatedCharacter.id} 
                     onChange={(e) => { setUpdatedId(e.target.value) }}></input> 
                </div>

                <div>
                    <label>Name:</label>
                    <input type="text" id="update-game-name" value={updatedCharacter.GameCharacterName} placeholder="Update Name" 
                    onChange={(e) => { setUpdatedName(e.target.value) }}></input>
                </div>

                <div >
                    <label>Game:</label>
                    <input type="text" id="update-game" value={updatedCharacter.game} placeholder="Update game" 
                    onChange={(e) => { setUpdatedGame(e.target.value) }}></input>
                </div>

                <div>
                    <label>Image:</label>
                    <input type="text" id="update-game-image" value={updatedCharacter.image} placeholder="Update Image" 
                    onChange={(e) => { setUpdatedImage(e.target.value) }}></input>
                </div>
            </div>

            <button id="update-game-btn" onClick={UpdateCharacter}>Update</button>
            <p>Remember to refresh the page to see the changes</p>
        </div>
    )
}
export default Update;