import axios from "axios";
import React from "react";
import { useEffect, useState } from "react";


//function delete character
function Delete({ onDeleteCharacter }) {
    const [GameCharacter, setDeletedCharacter] = useState([]);
    const [deleteId, setDeleteId] = useState("");

    //Axios delete
    function onDeleteCharacter(deleteId) {
        axios.delete(`https://localhost:7240/api/GameCharacter/${deleteId}`)
            .then((response) => { setDeletedCharacter(undefined) })
            .catch(error => {
                console.log(error);
            });
    }
    
    //useeffect
    useEffect(() => {
        setDeletedCharacter({ id: deleteId });
    }, [deleteId]);

    function deletedCharacter() {
        onDeleteCharacter(deleteId);
       
    }

    return (
        <div className="div">
            <h3>DELETE A GAME CHARACTER</h3>
            <input type="text" id="delete-game-Id" placeholder="Enter Id" onChange={(e) => setDeleteId(e.target.value)}></input>
            <p>Remember to refresh the page to see the changes</p>
            <button id="delete-game-btn" onClick={deletedCharacter}>Delete</button>
            
        </div>
    )
}

export default Delete;