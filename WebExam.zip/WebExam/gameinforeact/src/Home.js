import React from "react";

export default function Home() {
    return (

        <div className="container">
            <h1 className="header">Welcome to electric games!</h1>
            <h3>In this website you can check out different game characters from the popular game Valorant. </h3>
            <h3>In addition, you can delete, add, search and update game characters into our system.</h3>
            <h3>There is also a very exciting quiz waiting for you!</h3>

        </div>
    );


}