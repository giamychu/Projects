using GameInfoApi.Models;
using Microsoft.Extensions.Options;
using MongoDB.Driver;

namespace GameInfoApi.Services;

public class GameCharacterService
{
    private readonly IMongoCollection<GameCharacters> _gameCharacterCollection;

    public GameCharacterService(
        IOptions<GameInfoDatabaseSettings> GameInfoDatabaseSettings)
    {
        var mongoClient = new MongoClient(
            GameInfoDatabaseSettings.Value.ConnectionString);

        var mongoDatabase = mongoClient.GetDatabase(
            GameInfoDatabaseSettings.Value.DatabaseName);

        _gameCharacterCollection = mongoDatabase.GetCollection<GameCharacters>(
            GameInfoDatabaseSettings.Value.GameCharacterCollectionName);
    }

    public async Task<List<GameCharacters>> GetAsync() =>
        await _gameCharacterCollection.Find(_ => true).ToListAsync();

    public async Task<GameCharacters?> GetAsync(string id) =>
        await _gameCharacterCollection.Find(x => x.Id == id).FirstOrDefaultAsync();

    public async Task<List<GameCharacters>> SearchByName(string name) =>
    await _gameCharacterCollection.Find(x => x.GameCharacterName.Equals(name)).ToListAsync();

    public async Task CreateAsync(GameCharacters newGameCharacter) =>
        await _gameCharacterCollection.InsertOneAsync(newGameCharacter);

    public async Task UpdateAsync(string id, GameCharacters updatedGameCharacter) =>
        await _gameCharacterCollection.ReplaceOneAsync(x => x.Id == id, updatedGameCharacter);

     public async Task RemoveAsync(string id) =>
         await _gameCharacterCollection.DeleteOneAsync(x => x.Id == id);
}