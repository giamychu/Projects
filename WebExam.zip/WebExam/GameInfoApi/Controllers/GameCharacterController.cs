using GameInfoApi.Models;
using GameInfoApi.Services;
using Microsoft.AspNetCore.Mvc;

namespace GameInfoApi.Controllers;

[ApiController]
[Route("api/[controller]")]
public class GameCharacterController : ControllerBase
{
    private readonly GameCharacterService _GameCharacterService;

    public GameCharacterController(GameCharacterService GameCharacterService) =>
        _GameCharacterService = GameCharacterService;

    [HttpGet]
    public async Task<List<GameCharacters>> Get() =>
        await _GameCharacterService.GetAsync();

    //Get ID
    [HttpGet("{id:length(24)}")]
    public async Task<ActionResult<GameCharacters>> Get(string id)
    {
        var GameCharacters = await _GameCharacterService.GetAsync(id);

        if (GameCharacters is null)
        {
            return NotFound();
        }
        return GameCharacters;
    }

    [HttpGet("name/{name}")]

    public async Task<List<GameCharacters>> GetByName(string name) =>
    await _GameCharacterService.SearchByName(name);


    [HttpPost]
    public async Task<IActionResult> Post(GameCharacters newGameCharacter)
    {
        await _GameCharacterService.CreateAsync(newGameCharacter);

        return CreatedAtAction(nameof(Get), new { id = newGameCharacter.Id }, newGameCharacter);
    }

    [HttpPut("{id:length(24)}")]
    public async Task<IActionResult> Update(string id, GameCharacters updatedGameCharacter)
    {
        var GameCharacters = await _GameCharacterService.GetAsync(id);

        if (GameCharacters is null)
        {
            return NotFound();
        }

        updatedGameCharacter.Id = GameCharacters.Id;

        await _GameCharacterService.UpdateAsync(id, updatedGameCharacter);

        return NoContent();
    }

    [HttpDelete("{id:length(24)}")]
    public async Task<IActionResult> Delete(string id)
    {
        var GameCharacters = await _GameCharacterService.GetAsync(id);

        if (GameCharacters is null)
        {
            return NotFound();
        }

        await _GameCharacterService.RemoveAsync(id);

        return NoContent();
    }



}