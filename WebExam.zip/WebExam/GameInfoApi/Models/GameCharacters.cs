using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;

namespace GameInfoApi.Models;

public class GameCharacters
{
    [BsonId]
    [BsonRepresentation(BsonType.ObjectId)]
    public string? Id { get; set; }

    [BsonElement("GameCharacterName")]
    public string GameCharacterName { get; set; } = null!;

    public string Game { get; set; } = null!;

    public string Image { get; set; } = null!;

}