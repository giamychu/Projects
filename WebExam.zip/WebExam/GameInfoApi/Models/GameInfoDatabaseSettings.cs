namespace GameInfoApi.Models;

public class GameInfoDatabaseSettings
{
    public string ConnectionString { get; set; } = null!;

    public string DatabaseName { get; set; } = null!;

    public string GameCharacterCollectionName { get; set; } = null!;
}