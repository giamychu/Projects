using GameInfoApi.Models;
using GameInfoApi.Services;

var builder = WebApplication.CreateBuilder(args);

//add CORS
builder.Services.AddCors(
    options => {
        options.AddPolicy("AllowAnyOrigin",
        policies => policies
            .AllowAnyOrigin()
            .AllowAnyMethod()
            .AllowAnyHeader()
            );
    }
);

// Add services to the container.
builder.Services.Configure<GameInfoDatabaseSettings>(
    builder.Configuration.GetSection("GameInfoDatabase"));

    builder.Services.AddSingleton<GameCharacterService>();

builder.Services.AddControllers();


// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

//index.html
DefaultFilesOptions options = new DefaultFilesOptions();
options.DefaultFileNames.Add("index.html");
app.UseDefaultFiles(options);

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

//Use static files
app.UseStaticFiles();

app.UseHttpsRedirection();

app.UseAuthorization();

//Add Cors
app.UseCors("AllowAnyOrigin");

app.Run();
